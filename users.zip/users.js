var express = require('express');
var mysql      = require('mysql');
var router = express.Router();


/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});

router.post('/getInfo', function(req, res, next) {
  res.contentType('json');
  res.send(JSON.stringify({resutl:'success'}));
  res.end();
});

router.post('/addBigCat', function(req, res, next) {
    res.contentType('json');
    var connection = mysql.createConnection({
      host     : 'localhost',
      user     : 'root',
      password : 'root',
      database : 'a'
    });
    try{
      connection.connect();
      connection.query('insert into a(name) values("'+req.body.name+'");', function(err, rows) {
        if (err){
          throw err;
        }
        res.send(JSON.stringify({ id:rows.insertId}));
        res.end();
      });
    }catch(ex){
      console.log(ex);
    }finally{
      connection.end();
    }
});

router.post('/addSecondCat', function(req, res, next) {
  var connection = mysql.createConnection({
    host     : 'localhost',
    user     : 'root',
    password : 'root',
    database : 'a'
  });
  res.contentType('json');
  try{
    var insertSql = 'insert into b(pid,name) values('+req.body.id+',"'+req.body.name+'");';
    connection.connect();
    connection.query(insertSql, function(err, rows) {
      if (err){
        console.log("==============================have a error!");
      }
      res.send(JSON.stringify({ id:rows.insertId}));//���ͻ��˷���һ��json��ʽ������
      res.end();
    });
  }catch(ex){
    console.log(ex);
  }finally{
    connection.end();
  }
});

router.post('/addLastCat', function(req, res, next) {
  res.contentType('json');
  var connection = mysql.createConnection({
    host     : 'localhost',
    user     : 'root',
    password : 'root',
    database : 'a'
  });
  try{
    connection.connect();
    connection.query('insert into c(pid,name) values('+req.body.id+',"'+req.body.name+'");', function(err, rows) {
      if (err) throw err;
      res.send(JSON.stringify({ id:rows.insertId}));//���ͻ��˷���һ��json��ʽ������
      res.end();
    });
  }catch(ex){
    console.log(ex);
  }finally{
    connection.end();
  }

});

module.exports = router;